/* 
 * File:   main.cpp
 * Author: andrewnegrete
 *
 * Created on February 18, 2015, 1:21 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    int a, b, total;
    
    a = 50;
    b = 100;
    
    total = a + b;
    
    cout << "total is " << total << endl;
    
    return 0;
}

