/* 
 * File:   main.cpp
 * Author: andrewnegrete
 *
 * Created on February 18, 2015, 1:50 PM
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    float millimeters, f, s, t;
    
    millimeters = 1.5;
    
    f = 1.5 * 5;
    
    s = 1.5 * 7;
    
    t = 1.5 * 10;
    
    cout << "In five years the ocean will be " << f << " millimeters higher\n";
    cout << "In seven years the ocean will be " << s << " millimeters higher\n";
    cout << "In ten years the ocean will be " << t << " millimeters higher\n";
    
    return 0;
}

