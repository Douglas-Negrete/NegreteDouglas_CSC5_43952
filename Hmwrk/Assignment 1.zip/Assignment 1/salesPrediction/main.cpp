/* 
 * File:   main.cpp
 * Author: andrewnegrete
 *
 * Created on February 18, 2015, 1:25 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    float profit, sales;
    
    profit = 8.6;
    
    sales = 8.6 * .58;
    
    cout << "The East Coast Division has generated " << sales << 
                " million in profit" << endl;
    
    return 0;
}

